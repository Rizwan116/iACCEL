import React from 'react';

const ServiceInfo = () => {
    return (
        <div>
            <div>
                <div>
                        <h1>Investor Connectoers</h1>
                </div>

                <div>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Iure necessitatibus, animi minus reiciendis neque dignissimos!</p>

                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Iure necessitatibus,</p>

                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. </p>
                </div>
            </div>

            <div>
                <div>
                        <h1>Business Supprot</h1>
                </div>

                <div>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Iure necessitatibus, animi minus reiciendis neque dignissimos!</p>

                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Iure necessitatibus,</p>

                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. </p>
                </div>
            </div>

            <div>
                <div>
                        <h1>Entitiy Setup & Office Space</h1>
                </div>

                <div>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Iure necessitatibus, animi minus reiciendis neque dignissimos!</p>

                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Iure necessitatibus,</p>

                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. </p>
                </div>
            </div>
        </div>
    );
}

export default ServiceInfo;
