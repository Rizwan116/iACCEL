import React from 'react';

const ServiceCard = () => {
    return (
        <div>
                <h1>
                    Market Access
                </h1>

                <div>
                    <div>
                        <img src="" alt="" />

                        <p>para</p>
                    </div>

                      <div>
                        <img src="" alt="" />

                        <p>para</p>
                    </div>

                      <div>
                        <img src="" alt="" />

                        <p>para</p>
                    </div>
                </div>
       </div>
    );
}

export default ServiceCard;
