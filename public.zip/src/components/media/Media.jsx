import React from 'react';
import { Link } from 'react-router-dom';
import './Media.css';
import Hero from '../hero/Hero';

function Media() {
  
  return (
    <div>

       <Hero  backgroundImage="https://img.freepik.com/free-photo/beautiful-shot-mountain-covered-by-green-trees-with-beautiful-blue-sky-clouds-background_181624-16423.jpg"
      title="Media"
      text="Our Work speaks for itself"
      
     />
     

        <div>

            <h1>
              stay updated with news, <br />
              press realser and stories driving <br />
              our global journey
            </h1>

        </div>
            <div className='flex'>
              <div>
                 
                 <div>
                   <img src="" alt="" />
                  <h3>IAN GROUP and IACCEL GBI partnership</h3>
                  <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Obcaecati distinctio quos cum fuga consequuntur temporibus sequi dignissimos nisi fugit natus, totam at, modi nobis? Porro alias similique hic animi sequi?</p>

                  <div>
                    <p>08 June 2025</p>

                    <a href="readmore">Read More</a>
                  </div>
                 </div>
<hr />

                 <div>
                   <div>
                   <div>
                     <img src="https://img.freepik.com/free-vector/branding-identity-corporate-logo-vector-design-template_460848-13992.jpg?size=626&ext=jpg&ga=GA1.1.1824573526.1723610953&semt=ais_hybrid" alt="" />
                   </div>
                   <div>Lorem ipsum dolor sit amet consectetur adipisicing elit. Earum, temporibus!</div>
                  </div>

                  <div>
                   <p>08 June 2025</p>

                    <a href="readmore">Read More</a>
                  </div>
                 </div>

                 <hr />
              </div>

              <div>
                    
                <div>

                   <div>
                   <div>
                   <div>
                     <img src="https://img.freepik.com/free-vector/branding-identity-corporate-logo-vector-design-template_460848-13992.jpg?size=626&ext=jpg&ga=GA1.1.1824573526.1723610953&semt=ais_hybrid" alt="" />
                   </div>
                   <div>Lorem ipsum dolor sit amet consectetur adipisicing elit. Earum, temporibus!</div>
                  </div>

                  <div>
                   <p>08 June 2025</p>

                    <a href="readmore">Read More</a>
                  </div>
                 </div>

                  <hr />
                  <div>
                   <div>
                   <div>
                     <img src="https://img.freepik.com/free-vector/branding-identity-corporate-logo-vector-design-template_460848-13992.jpg?size=626&ext=jpg&ga=GA1.1.1824573526.1723610953&semt=ais_hybrid" alt="" />
                   </div>
                   <div>Lorem ipsum dolor sit amet consectetur adipisicing elit. Earum, temporibus!</div>
                  </div>

                  <div>
                   <p>08 June 2025</p>

                    <a href="readmore">Read More</a>
                  </div>
                 </div>

<hr />

                  <div>
                   <div>
                   <div>
                     <img src="https://img.freepik.com/free-vector/branding-identity-corporate-logo-vector-design-template_460848-13992.jpg?size=626&ext=jpg&ga=GA1.1.1824573526.1723610953&semt=ais_hybrid" alt="" />
                   </div>
                   <div>Lorem ipsum dolor sit amet consectetur adipisicing elit. Earum, temporibus!</div>
                  </div>

                  <div>
                   <p>08 June 2025</p>

                    <a href="readmore">Read More</a>
                  </div>
                 </div>

            <hr />

                  <div>
                   <div>
                   <div>
                     <img src="https://img.freepik.com/free-vector/branding-identity-corporate-logo-vector-design-template_460848-13992.jpg?size=626&ext=jpg&ga=GA1.1.1824573526.1723610953&semt=ais_hybrid" alt="" />
                   </div>
                   <div>Lorem ipsum dolor sit amet consectetur adipisicing elit. Earum, temporibus!</div>
                  </div>

                  <div>
                   <p>08 June 2025</p>

                    <a href="readmore">Read More</a>
                  </div>
                 </div>

                 <hr />
                 
                </div>
              </div>
            </div>

    </div>
  );
}

export default Media;
